-- Run this once in Supabase: SQL Editor -> New query -> paste -> Run
create table if not exists public.orders (
  id bigint generated always as identity primary key,
  name text not null,
  phone text not null,
  address text not null,
  quantity integer not null check (quantity between 1 and 5),
  total integer not null,
  created_at timestamptz not null default now()
);

-- The browser must not read or edit customer orders directly.
-- Netlify Functions use the private service-role key on the server.
alter table public.orders enable row level security;
