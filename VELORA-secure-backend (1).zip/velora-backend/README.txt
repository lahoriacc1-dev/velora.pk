VELORA secure backend starter
=============================

WHAT THIS ADDS
- Orders are saved in Supabase online, not in the customer's browser.
- Admin password is checked on the server, not stored in index.html.
- Admin orders are only available after server-verified login.
- Chatbot uses OpenAI to answer general questions and VELORA questions.
- API keys/passwords are environment variables, not included in this ZIP.

IMPORTANT: It will NOT work until you complete the setup below. Never put secret keys in index.html or in public GitHub files.

1) WEBSITE FILE LOCATION
This project uses public/index.html. In your GitHub repository, create a folder named public and move your current index.html into it (or use the included public/index.html to replace it). Keep netlify.toml and the netlify folder at the repository root.
The structure must look like this:
  netlify.toml
  schema.sql
  public/index.html
  netlify/functions/_shared.mjs
  netlify/functions/create-order.mjs
  netlify/functions/admin-login.mjs
  netlify/functions/admin-logout.mjs
  netlify/functions/admin-orders.mjs
  netlify/functions/chat.mjs

2) SUPABASE DATABASE
- Create a project at https://supabase.com/
- Open SQL Editor -> New query.
- Paste the contents of schema.sql and click Run.
- In Project Settings -> API, copy the Project URL and the private service-role/secret server key. Do NOT use the anon/public key for this backend, and never publish the private key.

3) OPENAI CHATBOT
- Create an API key at https://platform.openai.com/api-keys.
- API usage may cost money and may require billing. ChatGPT subscription and API billing are separate.
- If your account does not have access to gpt-4.1-mini, set OPENAI_MODEL to a model available to your API account.

4) NETLIFY ENVIRONMENT VARIABLES
In Netlify, open your site -> Site configuration -> Environment variables (or Project configuration -> Environment variables) and add these variables:
  SUPABASE_URL = your Supabase Project URL
  SUPABASE_SERVICE_ROLE_KEY = your private Supabase service-role/secret key
  ADMIN_PASSWORD = create a long, unique admin password
  SESSION_SECRET = a long random secret of at least 32 characters
  OPENAI_API_KEY = your OpenAI API key
  OPENAI_MODEL = gpt-4.1-mini (optional; only change if needed)
Save them, then trigger a fresh deploy. Do not add any of these values to HTML, GitHub, or this README.

5) DEPLOY / TEST
- Upload/commit the folder structure above to the same GitHub repository connected to Netlify.
- Wait for Netlify to finish deploying.
- Visit your website URL followed by #admin, for example https://your-site.netlify.app/#admin.
- Enter the ADMIN_PASSWORD you set in Netlify.
- Place a test order, then refresh the admin panel to confirm it appears.
- Ask the chatbot a general question and a VELORA question.

SECURITY NOTES
- Do not use the old hardcoded password VELORA2026; choose a new one and remove it from any old HTML/version you can control.
- If that old password was used anywhere else, change it there too.
- This starter keeps customer order data out of localStorage. Customers' browser history/network/devtools can still show their own form submission, but not the database service key or other customers' orders.
- Protect your GitHub account and Netlify/Supabase accounts with strong unique passwords and two-factor authentication.
- For a real shop, add spam/rate limiting, backups, privacy policy, and a verified delivery/payment workflow before taking customer orders at scale.
