import { json, readBody, methodOnly } from './_shared.mjs';
export default async (event) => {
  const methodError = methodOnly(event, 'POST'); if (methodError) return methodError;
  const message = String(readBody(event).message || '').trim().slice(0, 2000);
  if (!message) return json(400, { error: 'Please type a question.' });
  const key = process.env.OPENAI_API_KEY;
  if (!key) return json(503, { error: 'Chatbot is not configured yet.' });
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', max_tokens: 500, messages: [
        { role: 'system', content: 'You are the helpful website assistant for VELORA, a skincare brand. Answer the visitor’s actual question in clear, friendly language, including general non-harmful questions, not only brand questions. Be honest when unsure. Known site facts: VELORA lists one Face Scrub at Rs. 1,999; founder name shown on site is Abu Umama Yousafzai; Instagram is https://www.instagram.com/velora_personal_care/. The site does not provide a verified full ingredient list, certifications, stock status, delivery fees, or confirmed delivery timeline; do not invent these. Orders submitted on the site go to the configured order database. For medical/skin problems, give general information only, do not diagnose, recommend following the actual product label, patch testing, and consulting a qualified dermatologist for persistent symptoms or reactions. Never claim you personally placed an order or can see private customer order records. Be concise and respectful.' },
        { role: 'user', content: message }
      ] })
    });
    const data = await response.json();
    if (!response.ok) { console.error('OpenAI error:', response.status, JSON.stringify(data).slice(0, 500)); return json(502, { error: 'The chatbot could not answer right now.' }); }
    const answer = data.choices?.[0]?.message?.content?.trim();
    return json(200, { answer: answer || 'Sorry, I could not form an answer. Please try asking another way.' });
  } catch (e) { console.error('chat failed:', e.message); return json(502, { error: 'The chatbot could not connect right now.' }); }
};
