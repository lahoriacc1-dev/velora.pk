import { json, readBody, methodOnly, dbFetch, validSession, unauthorized } from './_shared.mjs';
export default async (event) => {
  if (!validSession(event)) return unauthorized();
  if (event.httpMethod === 'GET') {
    try { const orders = await dbFetch('orders?select=id,name,phone,address,quantity,total,created_at&order=created_at.desc'); return json(200, { orders }); }
    catch (e) { console.error('admin-orders GET failed:', e.message); return json(500, { error: 'Could not read orders. Check database setup.' }); }
  }
  const methodError = methodOnly(event, 'DELETE'); if (methodError) return methodError;
  const id = Number(readBody(event).id);
  if (!Number.isInteger(id) || id < 1) return json(400, { error: 'Invalid order ID.' });
  try { await dbFetch(`orders?id=eq.${id}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } }); return json(200, { ok: true }); }
  catch (e) { console.error('admin-orders DELETE failed:', e.message); return json(500, { error: 'Could not delete order.' }); }
};
