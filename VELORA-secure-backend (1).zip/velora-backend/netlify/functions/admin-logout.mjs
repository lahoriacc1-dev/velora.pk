import { json, methodOnly } from './_shared.mjs';
export default async (event) => {
  const methodError = methodOnly(event, 'POST'); if (methodError) return methodError;
  return json(200, { ok: true }, { 'Set-Cookie': 'velora_admin=; HttpOnly; Secure; SameSite=Strict; Path=/.netlify/functions/; Max-Age=0' });
};
