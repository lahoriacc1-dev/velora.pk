import { createHmac, timingSafeEqual } from 'node:crypto';

export function json(statusCode, body, extraHeaders = {}) {
  return { statusCode, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extraHeaders }, body: JSON.stringify(body) };
}
export function readBody(event) {
  try { return JSON.parse(event.body || '{}'); } catch { return {}; }
}
export function methodOnly(event, method) {
  return event.httpMethod === method ? null : json(405, { error: 'Method not allowed.' }, { Allow: method });
}
function secret(name) { const v = process.env[name]; if (!v) throw new Error(`Missing Netlify environment variable: ${name}`); return v; }
export function dbConfig() { return { url: secret('SUPABASE_URL').replace(/\/$/, ''), key: secret('SUPABASE_SERVICE_ROLE_KEY') }; }
export async function dbFetch(path, options = {}) {
  const { url, key } = dbConfig();
  const response = await fetch(`${url}/rest/v1/${path}`, { ...options, headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', ...options.headers } });
  const text = await response.text();
  if (!response.ok) throw new Error(`Database request failed (${response.status}): ${text.slice(0, 300)}`);
  return text ? JSON.parse(text) : null;
}
function signature(payload) { return createHmac('sha256', secret('SESSION_SECRET')).update(payload).digest('hex'); }
export function makeSession() { const payload = String(Date.now() + 8 * 60 * 60 * 1000); return `${payload}.${signature(payload)}`; }
export function validSession(event) {
  try {
    const cookies = event.headers?.cookie || event.headers?.Cookie || '';
    const token = cookies.split(';').map(x => x.trim()).find(x => x.startsWith('velora_admin='))?.slice('velora_admin='.length);
    if (!token) return false;
    const [payload, sig] = token.split('.');
    if (!payload || !sig || !/^\d+$/.test(payload) || Number(payload) < Date.now()) return false;
    const expected = signature(payload);
    const a = Buffer.from(sig, 'hex'), b = Buffer.from(expected, 'hex');
    return a.length === b.length && timingSafeEqual(a, b);
  } catch { return false; }
}
export function unauthorized() { return json(401, { error: 'Please log in to the admin panel again.' }); }
