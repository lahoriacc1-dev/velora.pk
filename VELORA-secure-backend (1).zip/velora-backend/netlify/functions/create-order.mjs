import { json, readBody, methodOnly, dbFetch } from './_shared.mjs';
export default async (event) => {
  const methodError = methodOnly(event, 'POST'); if (methodError) return methodError;
  const b = readBody(event);
  const name = String(b.name || '').trim().slice(0, 120);
  const phone = String(b.phone || '').trim().slice(0, 40);
  const address = String(b.address || '').trim().slice(0, 1000);
  const quantity = Number(b.quantity);
  if (!name || !phone || !address || !Number.isInteger(quantity) || quantity < 1 || quantity > 5) return json(400, { error: 'Please complete all fields and choose quantity 1–5.' });
  try {
    await dbFetch('orders', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ name, phone, address, quantity, total: quantity * 1999 }) });
    return json(201, { ok: true });
  } catch (e) { console.error('create-order failed:', e.message); return json(500, { error: 'Order service is not configured correctly. Please contact VELORA on Instagram.' }); }
};
