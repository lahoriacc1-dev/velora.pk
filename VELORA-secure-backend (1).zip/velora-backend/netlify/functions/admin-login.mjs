import { timingSafeEqual } from 'node:crypto';
import { json, readBody, methodOnly, makeSession } from './_shared.mjs';
export default async (event) => {
  const methodError = methodOnly(event, 'POST'); if (methodError) return methodError;
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return json(500, { error: 'Admin login is not configured in Netlify yet.' });
  const supplied = String(readBody(event).password || '');
  const a = Buffer.from(supplied), b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return json(401, { error: 'Incorrect admin password.' });
  const token = makeSession();
  return json(200, { ok: true }, { 'Set-Cookie': `velora_admin=${token}; HttpOnly; Secure; SameSite=Strict; Path=/.netlify/functions/; Max-Age=28800` });
};
